import React, { Component } from "react";
import UploadService from "../services/upload-files.service";
import "../components/display.css";

class DisplayFiles extends Component {
  constructor(props) {
    super(props);

    this.state = {
      selectedFiles: undefined,
      currentFile: undefined,
      progress: 0,
      message: "",
      fileInfos: [],
    };
  }
  componentDidMount() {
    UploadService.getFiles().then((response) => {
      this.setState({
        fileInfos: response.data,
      });
    });
  }

  render() {
    const { fileInfos } = this.state;

    return (
      <div className="main">
        <div className="card">
          <div className="card-header">List of Files</div>
          {fileInfos &&
            fileInfos.map((file, index) => (
              <li className="list-group-item" key={index}>
                <a href={file.url}>{file.name}</a>
              </li>
            ))}
        </div>
      </div>
    );
  }
}

export default DisplayFiles;
